<?php

namespace BackofficeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BackofficeBundle extends Bundle
{
}
